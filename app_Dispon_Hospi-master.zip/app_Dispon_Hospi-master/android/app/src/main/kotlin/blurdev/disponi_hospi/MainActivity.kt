package blurdev.disponi_hospi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
