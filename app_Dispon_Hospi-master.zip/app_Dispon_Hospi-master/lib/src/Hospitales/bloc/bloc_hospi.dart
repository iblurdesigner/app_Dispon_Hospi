import 'package:generic_bloc_provider/generic_bloc_provider.dart';

class HospiBloc implements Bloc {

  @override
  void dispose() {

  }
}