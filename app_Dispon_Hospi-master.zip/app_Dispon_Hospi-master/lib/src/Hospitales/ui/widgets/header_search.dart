import 'package:flutter/material.dart';

class HeaderSearch extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    //throw UnimplementedError();

   return Column(
     children: <Widget>[
       Container(
         child: Image.asset(
             'assets/img/header@2x.png'
         ),
       )
     ],
   );


  }



}