import 'package:generic_bloc_provider/generic_bloc_provider.dart';

class UserBloc implements Bloc {

  @override
  void dispose() {

  }
}